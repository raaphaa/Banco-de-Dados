--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;

ALTER TABLE ONLY public.produto_pedido DROP CONSTRAINT produto_pedido_cod_produto_fkey;
ALTER TABLE ONLY public.produto_pedido DROP CONSTRAINT produto_pedido_cod_pedido_fkey;
ALTER TABLE ONLY public.produto_funcionario DROP CONSTRAINT produto_funcionario_cod_produto_fkey;
ALTER TABLE ONLY public.produto_funcionario DROP CONSTRAINT produto_funcionario_cod_funcionario_fkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_cod_estoque_fkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_cod_categoria_fkey;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_cod_cliente_fkey;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_cod_estoque_fkey;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_cod_endereco_fkey1;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_cod_endereco_fkey;
ALTER TABLE ONLY public.envio DROP CONSTRAINT envio_cod_pedido_fkey;
ALTER TABLE ONLY public.envio DROP CONSTRAINT envio_cod_funcionario_fkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_cod_endereco_fkey1;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_cod_endereco_fkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT uni;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_pkey;
ALTER TABLE ONLY public.produto_pedido DROP CONSTRAINT produto_pedido_pkey;
ALTER TABLE ONLY public.produto_funcionario DROP CONSTRAINT produto_funcionario_pkey;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_pkey;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_pkey;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_nome_usuario_key;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_cpf_key;
ALTER TABLE ONLY public.estoque DROP CONSTRAINT estoque_pkey;
ALTER TABLE ONLY public.envio DROP CONSTRAINT envio_pkey;
ALTER TABLE ONLY public.endereco DROP CONSTRAINT endereco_pkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_pkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_nome_usuario_key;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_email_key;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_cpf_key;
ALTER TABLE ONLY public.categoria DROP CONSTRAINT categoria_pkey;
ALTER TABLE public.produto_pedido ALTER COLUMN cod_produto_pedido DROP DEFAULT;
ALTER TABLE public.produto_funcionario ALTER COLUMN cod_produto_funcionario DROP DEFAULT;
ALTER TABLE public.produto ALTER COLUMN cod_produto DROP DEFAULT;
ALTER TABLE public.pedido ALTER COLUMN cod_pedido DROP DEFAULT;
ALTER TABLE public.funcionario ALTER COLUMN cod_funcionario DROP DEFAULT;
ALTER TABLE public.estoque ALTER COLUMN cod_estoque DROP DEFAULT;
ALTER TABLE public.envio ALTER COLUMN cod_envio DROP DEFAULT;
ALTER TABLE public.endereco ALTER COLUMN cod_endereco DROP DEFAULT;
ALTER TABLE public.cliente ALTER COLUMN cod_cliente DROP DEFAULT;
ALTER TABLE public.categoria ALTER COLUMN cod_categoria DROP DEFAULT;
DROP SEQUENCE public.produto_pedido_cod_produto_pedido_seq;
DROP TABLE public.produto_pedido;
DROP SEQUENCE public.produto_funcionario_cod_produto_funcionario_seq;
DROP TABLE public.produto_funcionario;
DROP SEQUENCE public.produto_cod_produto_seq;
DROP TABLE public.produto;
DROP SEQUENCE public.pedido_cod_pedido_seq;
DROP TABLE public.pedido;
DROP SEQUENCE public.funcionario_cod_funcionario_seq;
DROP TABLE public.funcionario;
DROP SEQUENCE public.estoque_cod_estoque_seq;
DROP TABLE public.estoque;
DROP SEQUENCE public.envio_cod_envio_seq;
DROP TABLE public.envio;
DROP SEQUENCE public.endereco_cod_endereco_seq;
DROP TABLE public.endereco;
DROP SEQUENCE public.cliente_cod_cliente_seq;
DROP TABLE public.cliente;
DROP SEQUENCE public.categoria_cod_categoria_seq;
DROP TABLE public.categoria;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.categoria (
    cod_categoria integer NOT NULL,
    nome character varying(60) NOT NULL,
    "descrição" character varying(100)
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_cod_categoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_cod_categoria_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_cod_categoria_seq OWNER TO postgres;

--
-- Name: categoria_cod_categoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_cod_categoria_seq OWNED BY public.categoria.cod_categoria;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.cliente (
    cod_cliente integer NOT NULL,
    nome_completo character varying(50) NOT NULL,
    nome_usuario character varying(21) NOT NULL,
    senha character varying(8) NOT NULL,
    email character varying(30) NOT NULL,
    cpf character varying(14) NOT NULL,
    data_nascimento date NOT NULL,
    cod_endereco integer
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: cliente_cod_cliente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_cod_cliente_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cliente_cod_cliente_seq OWNER TO postgres;

--
-- Name: cliente_cod_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_cod_cliente_seq OWNED BY public.cliente.cod_cliente;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.endereco (
    cod_endereco integer NOT NULL,
    cep character(9) NOT NULL,
    logradouro character varying(10),
    lote character(5),
    quadra character(5),
    tipo_moradia character varying(15) NOT NULL,
    complemento character varying(30),
    referencia character varying(50),
    numero character varying(5) NOT NULL,
    bairro character varying(30) NOT NULL,
    cidade character varying(30) NOT NULL,
    estado character varying(30) NOT NULL,
    sigla_estado character varying(2) NOT NULL,
    rua character varying(50)
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_cod_endereco_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_cod_endereco_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.endereco_cod_endereco_seq OWNER TO postgres;

--
-- Name: endereco_cod_endereco_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_cod_endereco_seq OWNED BY public.endereco.cod_endereco;


--
-- Name: envio; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.envio (
    cod_envio integer NOT NULL,
    data_envio date NOT NULL,
    cod_pedido integer,
    cod_funcionario integer
);


ALTER TABLE public.envio OWNER TO postgres;

--
-- Name: envio_cod_envio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.envio_cod_envio_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.envio_cod_envio_seq OWNER TO postgres;

--
-- Name: envio_cod_envio_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.envio_cod_envio_seq OWNED BY public.envio.cod_envio;


--
-- Name: estoque; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.estoque (
    cod_estoque integer NOT NULL,
    quantidade_produtos_em_estoque integer NOT NULL
);


ALTER TABLE public.estoque OWNER TO postgres;

--
-- Name: estoque_cod_estoque_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estoque_cod_estoque_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estoque_cod_estoque_seq OWNER TO postgres;

--
-- Name: estoque_cod_estoque_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estoque_cod_estoque_seq OWNED BY public.estoque.cod_estoque;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.funcionario (
    cod_funcionario integer NOT NULL,
    nome_completo character varying(50) NOT NULL,
    nome_usuario character varying(15) NOT NULL,
    senha character varying(8) NOT NULL,
    cpf character varying(14) NOT NULL,
    data_nascimento date NOT NULL,
    data_admissao date NOT NULL,
    cod_estoque integer,
    cod_endereco integer
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: funcionario_cod_funcionario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funcionario_cod_funcionario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.funcionario_cod_funcionario_seq OWNER TO postgres;

--
-- Name: funcionario_cod_funcionario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funcionario_cod_funcionario_seq OWNED BY public.funcionario.cod_funcionario;


--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.pedido (
    cod_pedido integer NOT NULL,
    data_pedido date NOT NULL,
    cod_cliente integer
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: pedido_cod_pedido_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_cod_pedido_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_cod_pedido_seq OWNER TO postgres;

--
-- Name: pedido_cod_pedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_cod_pedido_seq OWNED BY public.pedido.cod_pedido;


--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.produto (
    cod_produto integer NOT NULL,
    nome character varying(200) NOT NULL,
    data_fabricacao date NOT NULL,
    valor_unitario money NOT NULL,
    cod_categoria integer,
    cod_estoque integer,
    descricao character varying(5000)
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: produto_cod_produto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_cod_produto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_cod_produto_seq OWNER TO postgres;

--
-- Name: produto_cod_produto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_cod_produto_seq OWNED BY public.produto.cod_produto;


--
-- Name: produto_funcionario; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.produto_funcionario (
    cod_produto_funcionario integer NOT NULL,
    cod_produto integer,
    cod_funcionario integer
);


ALTER TABLE public.produto_funcionario OWNER TO postgres;

--
-- Name: produto_funcionario_cod_produto_funcionario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_funcionario_cod_produto_funcionario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_funcionario_cod_produto_funcionario_seq OWNER TO postgres;

--
-- Name: produto_funcionario_cod_produto_funcionario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_funcionario_cod_produto_funcionario_seq OWNED BY public.produto_funcionario.cod_produto_funcionario;


--
-- Name: produto_pedido; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.produto_pedido (
    cod_produto_pedido integer NOT NULL,
    cod_produto integer,
    cod_pedido integer
);


ALTER TABLE public.produto_pedido OWNER TO postgres;

--
-- Name: produto_pedido_cod_produto_pedido_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_pedido_cod_produto_pedido_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_pedido_cod_produto_pedido_seq OWNER TO postgres;

--
-- Name: produto_pedido_cod_produto_pedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_pedido_cod_produto_pedido_seq OWNED BY public.produto_pedido.cod_produto_pedido;


--
-- Name: cod_categoria; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN cod_categoria SET DEFAULT nextval('public.categoria_cod_categoria_seq'::regclass);


--
-- Name: cod_cliente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN cod_cliente SET DEFAULT nextval('public.cliente_cod_cliente_seq'::regclass);


--
-- Name: cod_endereco; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN cod_endereco SET DEFAULT nextval('public.endereco_cod_endereco_seq'::regclass);


--
-- Name: cod_envio; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.envio ALTER COLUMN cod_envio SET DEFAULT nextval('public.envio_cod_envio_seq'::regclass);


--
-- Name: cod_estoque; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque ALTER COLUMN cod_estoque SET DEFAULT nextval('public.estoque_cod_estoque_seq'::regclass);


--
-- Name: cod_funcionario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN cod_funcionario SET DEFAULT nextval('public.funcionario_cod_funcionario_seq'::regclass);


--
-- Name: cod_pedido; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido ALTER COLUMN cod_pedido SET DEFAULT nextval('public.pedido_cod_pedido_seq'::regclass);


--
-- Name: cod_produto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN cod_produto SET DEFAULT nextval('public.produto_cod_produto_seq'::regclass);


--
-- Name: cod_produto_funcionario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_funcionario ALTER COLUMN cod_produto_funcionario SET DEFAULT nextval('public.produto_funcionario_cod_produto_funcionario_seq'::regclass);


--
-- Name: cod_produto_pedido; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_pedido ALTER COLUMN cod_produto_pedido SET DEFAULT nextval('public.produto_pedido_cod_produto_pedido_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2048.dat

--
-- Name: categoria_cod_categoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_cod_categoria_seq', 5, true);


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2042.dat

--
-- Name: cliente_cod_cliente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_cod_cliente_seq', 11, true);


--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2060.dat

--
-- Name: endereco_cod_endereco_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_cod_endereco_seq', 19, true);


--
-- Data for Name: envio; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2058.dat

--
-- Name: envio_cod_envio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.envio_cod_envio_seq', 1, false);


--
-- Data for Name: estoque; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2044.dat

--
-- Name: estoque_cod_estoque_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estoque_cod_estoque_seq', 1, false);


--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2054.dat

--
-- Name: funcionario_cod_funcionario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funcionario_cod_funcionario_seq', 1, false);


--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2046.dat

--
-- Name: pedido_cod_pedido_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_cod_pedido_seq', 1, false);


--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2050.dat

--
-- Name: produto_cod_produto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_cod_produto_seq', 42, true);


--
-- Data for Name: produto_funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2056.dat

--
-- Name: produto_funcionario_cod_produto_funcionario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_funcionario_cod_produto_funcionario_seq', 1, false);


--
-- Data for Name: produto_pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2052.dat

--
-- Name: produto_pedido_cod_produto_pedido_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_pedido_cod_produto_pedido_seq', 1, false);


--
-- Name: categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (cod_categoria);


--
-- Name: cliente_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_cpf_key UNIQUE (cpf);


--
-- Name: cliente_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_email_key UNIQUE (email);


--
-- Name: cliente_nome_usuario_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_nome_usuario_key UNIQUE (nome_usuario);


--
-- Name: cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (cod_cliente);


--
-- Name: endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (cod_endereco);


--
-- Name: envio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.envio
    ADD CONSTRAINT envio_pkey PRIMARY KEY (cod_envio);


--
-- Name: estoque_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.estoque
    ADD CONSTRAINT estoque_pkey PRIMARY KEY (cod_estoque);


--
-- Name: funcionario_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_cpf_key UNIQUE (cpf);


--
-- Name: funcionario_nome_usuario_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_nome_usuario_key UNIQUE (nome_usuario);


--
-- Name: funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (cod_funcionario);


--
-- Name: pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (cod_pedido);


--
-- Name: produto_funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.produto_funcionario
    ADD CONSTRAINT produto_funcionario_pkey PRIMARY KEY (cod_produto_funcionario);


--
-- Name: produto_pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.produto_pedido
    ADD CONSTRAINT produto_pedido_pkey PRIMARY KEY (cod_produto_pedido);


--
-- Name: produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (cod_produto);


--
-- Name: uni; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT uni UNIQUE (cpf);


--
-- Name: cliente_cod_endereco_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_cod_endereco_fkey FOREIGN KEY (cod_endereco) REFERENCES public.endereco(cod_endereco);


--
-- Name: cliente_cod_endereco_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_cod_endereco_fkey1 FOREIGN KEY (cod_endereco) REFERENCES public.endereco(cod_endereco);


--
-- Name: envio_cod_funcionario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.envio
    ADD CONSTRAINT envio_cod_funcionario_fkey FOREIGN KEY (cod_funcionario) REFERENCES public.funcionario(cod_funcionario);


--
-- Name: envio_cod_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.envio
    ADD CONSTRAINT envio_cod_pedido_fkey FOREIGN KEY (cod_pedido) REFERENCES public.pedido(cod_pedido);


--
-- Name: funcionario_cod_endereco_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_cod_endereco_fkey FOREIGN KEY (cod_endereco) REFERENCES public.endereco(cod_endereco);


--
-- Name: funcionario_cod_endereco_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_cod_endereco_fkey1 FOREIGN KEY (cod_endereco) REFERENCES public.endereco(cod_endereco);


--
-- Name: funcionario_cod_estoque_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_cod_estoque_fkey FOREIGN KEY (cod_estoque) REFERENCES public.estoque(cod_estoque);


--
-- Name: pedido_cod_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_cod_cliente_fkey FOREIGN KEY (cod_cliente) REFERENCES public.cliente(cod_cliente);


--
-- Name: produto_cod_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_cod_categoria_fkey FOREIGN KEY (cod_categoria) REFERENCES public.categoria(cod_categoria);


--
-- Name: produto_cod_estoque_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_cod_estoque_fkey FOREIGN KEY (cod_estoque) REFERENCES public.estoque(cod_estoque);


--
-- Name: produto_funcionario_cod_funcionario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_funcionario
    ADD CONSTRAINT produto_funcionario_cod_funcionario_fkey FOREIGN KEY (cod_funcionario) REFERENCES public.funcionario(cod_funcionario);


--
-- Name: produto_funcionario_cod_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_funcionario
    ADD CONSTRAINT produto_funcionario_cod_produto_fkey FOREIGN KEY (cod_produto) REFERENCES public.produto(cod_produto);


--
-- Name: produto_pedido_cod_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_pedido
    ADD CONSTRAINT produto_pedido_cod_pedido_fkey FOREIGN KEY (cod_pedido) REFERENCES public.pedido(cod_pedido);


--
-- Name: produto_pedido_cod_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_pedido
    ADD CONSTRAINT produto_pedido_cod_produto_fkey FOREIGN KEY (cod_produto) REFERENCES public.produto(cod_produto);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

