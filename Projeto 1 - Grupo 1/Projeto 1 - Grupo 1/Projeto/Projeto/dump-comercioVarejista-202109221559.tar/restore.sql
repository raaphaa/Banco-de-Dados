--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;

ALTER TABLE ONLY public.produto_pedido DROP CONSTRAINT produto_pedido_cod_produto_fkey;
ALTER TABLE ONLY public.produto_pedido DROP CONSTRAINT produto_pedido_cod_pedido_fkey;
ALTER TABLE ONLY public.produto_funcionario DROP CONSTRAINT produto_funcionario_cod_produto_fkey;
ALTER TABLE ONLY public.produto_funcionario DROP CONSTRAINT produto_funcionario_cod_funcionario_fkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_cod_estoque_fkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_cod_categoria_fkey;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_cod_cliente_fkey;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_cod_endereco_fkey;
ALTER TABLE ONLY public.envio DROP CONSTRAINT envio_cod_pedido_fkey;
ALTER TABLE ONLY public.envio DROP CONSTRAINT envio_cod_funcionario_fkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_cod_endereco_fkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT uni;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_pkey;
ALTER TABLE ONLY public.produto_pedido DROP CONSTRAINT produto_pedido_pkey;
ALTER TABLE ONLY public.produto_funcionario DROP CONSTRAINT produto_funcionario_pkey;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_pkey;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_pkey;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_nome_usuario_key;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_cpf_key;
ALTER TABLE ONLY public.estoque DROP CONSTRAINT estoque_pkey;
ALTER TABLE ONLY public.envio DROP CONSTRAINT envio_pkey;
ALTER TABLE ONLY public.endereco DROP CONSTRAINT endereco_pkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_pkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_nome_usuario_key;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_email_key;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_cpf_key;
ALTER TABLE ONLY public.categoria DROP CONSTRAINT categoria_pkey;
ALTER TABLE public.produto_pedido ALTER COLUMN cod_produto_pedido DROP DEFAULT;
ALTER TABLE public.produto_funcionario ALTER COLUMN cod_produto_funcionario DROP DEFAULT;
ALTER TABLE public.produto ALTER COLUMN cod_produto DROP DEFAULT;
ALTER TABLE public.pedido ALTER COLUMN cod_pedido DROP DEFAULT;
ALTER TABLE public.funcionario ALTER COLUMN cod_funcionario DROP DEFAULT;
ALTER TABLE public.estoque ALTER COLUMN cod_estoque DROP DEFAULT;
ALTER TABLE public.envio ALTER COLUMN cod_envio DROP DEFAULT;
ALTER TABLE public.endereco ALTER COLUMN cod_endereco DROP DEFAULT;
ALTER TABLE public.cliente ALTER COLUMN cod_cliente DROP DEFAULT;
ALTER TABLE public.categoria ALTER COLUMN cod_categoria DROP DEFAULT;
DROP VIEW public.relatorio_de_vendas;
DROP VIEW public.produtos_geridos_por_funcionario;
DROP SEQUENCE public.produto_pedido_cod_produto_pedido_seq;
DROP SEQUENCE public.produto_funcionario_cod_produto_funcionario_seq;
DROP SEQUENCE public.produto_cod_produto_seq;
DROP SEQUENCE public.pedido_cod_pedido_seq;
DROP VIEW public.notafiscal_pedido_7;
DROP VIEW public.notafiscal_pedido_6;
DROP VIEW public.notafiscal_pedido_5;
DROP VIEW public.notafiscal_pedido_4;
DROP VIEW public.notafiscal_pedido_3;
DROP VIEW public.notafiscal_pedido_2;
DROP VIEW public.notafiscal_pedido_1;
DROP TABLE public.produto_pedido;
DROP TABLE public.produto_funcionario;
DROP TABLE public.pedido;
DROP SEQUENCE public.funcionario_cod_funcionario_seq;
DROP TABLE public.funcionario;
DROP VIEW public.estoque_dos_produtos;
DROP SEQUENCE public.estoque_cod_estoque_seq;
DROP SEQUENCE public.envio_cod_envio_seq;
DROP TABLE public.envio;
DROP SEQUENCE public.endereco_cod_endereco_seq;
DROP TABLE public.endereco;
DROP VIEW public.controle_de_estoque;
DROP TABLE public.produto;
DROP TABLE public.estoque;
DROP SEQUENCE public.cliente_cod_cliente_seq;
DROP TABLE public.cliente;
DROP SEQUENCE public.categoria_cod_categoria_seq;
DROP TABLE public.categoria;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.categoria (
    cod_categoria integer NOT NULL,
    nome character varying(60) NOT NULL,
    "descrição" character varying(100)
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_cod_categoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_cod_categoria_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_cod_categoria_seq OWNER TO postgres;

--
-- Name: categoria_cod_categoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_cod_categoria_seq OWNED BY public.categoria.cod_categoria;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.cliente (
    cod_cliente integer NOT NULL,
    nome_completo character varying(50) NOT NULL,
    nome_usuario character varying(21) NOT NULL,
    senha character varying(8) NOT NULL,
    email character varying(30) NOT NULL,
    cpf character varying(14) NOT NULL,
    data_nascimento date NOT NULL,
    cod_endereco integer
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: cliente_cod_cliente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_cod_cliente_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cliente_cod_cliente_seq OWNER TO postgres;

--
-- Name: cliente_cod_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_cod_cliente_seq OWNED BY public.cliente.cod_cliente;


--
-- Name: estoque; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.estoque (
    cod_estoque integer NOT NULL,
    quantidade_produtos_em_estoque integer NOT NULL
);


ALTER TABLE public.estoque OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.produto (
    cod_produto integer NOT NULL,
    nome character varying(200) NOT NULL,
    data_fabricacao date NOT NULL,
    valor_unitario money NOT NULL,
    cod_categoria integer,
    cod_estoque integer,
    descricao character varying(5000)
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: controle_de_estoque; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.controle_de_estoque AS
 SELECT prod.nome AS produto,
    prod.descricao AS "descrição",
    cat.nome AS categoria,
    prod.data_fabricacao,
    prod.valor_unitario,
    e.quantidade_produtos_em_estoque AS estoque
   FROM ((public.produto prod
     LEFT JOIN public.categoria cat ON ((cat.cod_categoria = prod.cod_categoria)))
     LEFT JOIN public.estoque e ON ((e.cod_estoque = prod.cod_estoque)))
  GROUP BY prod.nome, prod.descricao, cat.nome, prod.data_fabricacao, prod.valor_unitario, e.quantidade_produtos_em_estoque;


ALTER TABLE public.controle_de_estoque OWNER TO postgres;

--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.endereco (
    cod_endereco integer NOT NULL,
    cep character(9) NOT NULL,
    logradouro character varying(10),
    lote character(5),
    quadra character(5),
    tipo_moradia character varying(15) NOT NULL,
    complemento character varying(30),
    referencia character varying(50),
    numero character varying(5) NOT NULL,
    bairro character varying(30) NOT NULL,
    cidade character varying(30) NOT NULL,
    estado character varying(30) NOT NULL,
    sigla_estado character varying(2) NOT NULL,
    rua character varying(50)
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_cod_endereco_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_cod_endereco_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.endereco_cod_endereco_seq OWNER TO postgres;

--
-- Name: endereco_cod_endereco_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_cod_endereco_seq OWNED BY public.endereco.cod_endereco;


--
-- Name: envio; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.envio (
    cod_envio integer NOT NULL,
    data_envio date NOT NULL,
    cod_pedido integer,
    cod_funcionario integer
);


ALTER TABLE public.envio OWNER TO postgres;

--
-- Name: envio_cod_envio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.envio_cod_envio_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.envio_cod_envio_seq OWNER TO postgres;

--
-- Name: envio_cod_envio_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.envio_cod_envio_seq OWNED BY public.envio.cod_envio;


--
-- Name: estoque_cod_estoque_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estoque_cod_estoque_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estoque_cod_estoque_seq OWNER TO postgres;

--
-- Name: estoque_cod_estoque_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estoque_cod_estoque_seq OWNED BY public.estoque.cod_estoque;


--
-- Name: estoque_dos_produtos; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.estoque_dos_produtos AS
 SELECT p.nome,
    e.quantidade_produtos_em_estoque
   FROM public.produto p,
    public.estoque e
  WHERE (p.cod_produto = e.cod_estoque);


ALTER TABLE public.estoque_dos_produtos OWNER TO postgres;

--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.funcionario (
    cod_funcionario integer NOT NULL,
    nome_completo character varying(50) NOT NULL,
    nome_usuario character varying(15) NOT NULL,
    senha character varying(8) NOT NULL,
    cpf character varying(14) NOT NULL,
    data_nascimento date NOT NULL,
    data_admissao date NOT NULL,
    cod_endereco integer
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: funcionario_cod_funcionario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funcionario_cod_funcionario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.funcionario_cod_funcionario_seq OWNER TO postgres;

--
-- Name: funcionario_cod_funcionario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funcionario_cod_funcionario_seq OWNED BY public.funcionario.cod_funcionario;


--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.pedido (
    cod_pedido integer NOT NULL,
    data_pedido date NOT NULL,
    cod_cliente integer
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: produto_funcionario; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.produto_funcionario (
    cod_produto_funcionario integer NOT NULL,
    cod_produto integer,
    cod_funcionario integer
);


ALTER TABLE public.produto_funcionario OWNER TO postgres;

--
-- Name: produto_pedido; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.produto_pedido (
    cod_produto_pedido integer NOT NULL,
    cod_produto integer,
    cod_pedido integer,
    quantidade_itens_pedido integer
);


ALTER TABLE public.produto_pedido OWNER TO postgres;

--
-- Name: notafiscal_pedido_1; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.notafiscal_pedido_1 AS
 SELECT cli.nome_completo AS cliente,
    cli.cpf,
    ende.cep,
    ped.cod_pedido,
    ped.data_pedido,
    prod.cod_produto,
    prod.nome AS produto,
    pp.quantidade_itens_pedido,
    prod.valor_unitario,
    en.cod_envio,
    en.data_envio,
    cat.nome AS categoria,
    f.nome_completo AS funcionario,
    ( SELECT count(produto_pedido.cod_pedido) AS produtos_no_pedido
           FROM public.produto_pedido
          WHERE (produto_pedido.cod_pedido = 1)) AS produtos_no_pedido,
    ( SELECT sum((p.valor_unitario * pp_1.quantidade_itens_pedido)) AS total_do_pedido
           FROM (public.produto_pedido pp_1
             JOIN public.produto p ON ((p.cod_produto = pp_1.cod_produto)))
          WHERE (pp_1.cod_pedido = 1)) AS total_do_pedido
   FROM ((((((((public.envio en
     LEFT JOIN public.pedido ped ON ((ped.cod_pedido = en.cod_pedido)))
     LEFT JOIN public.cliente cli ON ((cli.cod_cliente = ped.cod_cliente)))
     LEFT JOIN public.endereco ende ON ((ende.cod_endereco = cli.cod_endereco)))
     LEFT JOIN public.produto_pedido pp ON ((pp.cod_pedido = ped.cod_pedido)))
     LEFT JOIN public.produto prod ON ((prod.cod_produto = pp.cod_produto)))
     LEFT JOIN public.produto_funcionario pf ON ((pf.cod_produto = prod.cod_produto)))
     LEFT JOIN public.funcionario f ON ((f.cod_funcionario = pf.cod_funcionario)))
     LEFT JOIN public.categoria cat ON ((cat.cod_categoria = prod.cod_categoria)))
  WHERE (en.cod_pedido IN ( SELECT ped_1.cod_pedido
           FROM (public.pedido ped_1
             JOIN public.envio en_1 ON ((en_1.cod_pedido = ped_1.cod_pedido)))
          WHERE (en_1.cod_pedido = 1)))
  GROUP BY cli.nome_completo, cli.cpf, ende.cep, ped.cod_pedido, ped.data_pedido, prod.cod_produto, prod.nome, pp.quantidade_itens_pedido, prod.valor_unitario, en.cod_envio, en.data_envio, cat.nome, f.nome_completo;


ALTER TABLE public.notafiscal_pedido_1 OWNER TO postgres;

--
-- Name: notafiscal_pedido_2; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.notafiscal_pedido_2 AS
 SELECT cli.nome_completo AS cliente,
    cli.cpf,
    ende.cep,
    ped.cod_pedido,
    ped.data_pedido,
    prod.cod_produto,
    prod.nome AS produto,
    pp.quantidade_itens_pedido,
    prod.valor_unitario,
    en.cod_envio,
    en.data_envio,
    cat.nome AS categoria,
    f.nome_completo AS funcionario,
    ( SELECT count(produto_pedido.cod_pedido) AS produtos_no_pedido
           FROM public.produto_pedido
          WHERE (produto_pedido.cod_pedido = 2)) AS produtos_no_pedido,
    ( SELECT sum((p.valor_unitario * pp_1.quantidade_itens_pedido)) AS total_do_pedido
           FROM (public.produto_pedido pp_1
             JOIN public.produto p ON ((p.cod_produto = pp_1.cod_produto)))
          WHERE (pp_1.cod_pedido = 2)) AS total_do_pedido
   FROM ((((((((public.envio en
     LEFT JOIN public.pedido ped ON ((ped.cod_pedido = en.cod_pedido)))
     LEFT JOIN public.cliente cli ON ((cli.cod_cliente = ped.cod_cliente)))
     LEFT JOIN public.endereco ende ON ((ende.cod_endereco = cli.cod_endereco)))
     LEFT JOIN public.produto_pedido pp ON ((pp.cod_pedido = ped.cod_pedido)))
     LEFT JOIN public.produto prod ON ((prod.cod_produto = pp.cod_produto)))
     LEFT JOIN public.produto_funcionario pf ON ((pf.cod_produto = prod.cod_produto)))
     LEFT JOIN public.funcionario f ON ((f.cod_funcionario = pf.cod_funcionario)))
     LEFT JOIN public.categoria cat ON ((cat.cod_categoria = prod.cod_categoria)))
  WHERE (en.cod_pedido IN ( SELECT ped_1.cod_pedido
           FROM (public.pedido ped_1
             JOIN public.envio en_1 ON ((en_1.cod_pedido = ped_1.cod_pedido)))
          WHERE (en_1.cod_pedido = 2)))
  GROUP BY cli.nome_completo, cli.cpf, ende.cep, ped.cod_pedido, ped.data_pedido, prod.cod_produto, prod.nome, pp.quantidade_itens_pedido, prod.valor_unitario, en.cod_envio, en.data_envio, cat.nome, f.nome_completo;


ALTER TABLE public.notafiscal_pedido_2 OWNER TO postgres;

--
-- Name: notafiscal_pedido_3; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.notafiscal_pedido_3 AS
 SELECT cli.nome_completo AS cliente,
    cli.cpf,
    ende.cep,
    ped.cod_pedido,
    ped.data_pedido,
    prod.cod_produto,
    prod.nome AS produto,
    pp.quantidade_itens_pedido,
    prod.valor_unitario,
    en.cod_envio,
    en.data_envio,
    cat.nome AS categoria,
    f.nome_completo AS funcionario,
    ( SELECT count(produto_pedido.cod_pedido) AS produtos_no_pedido
           FROM public.produto_pedido
          WHERE (produto_pedido.cod_pedido = 3)) AS produtos_no_pedido,
    ( SELECT sum((p.valor_unitario * pp_1.quantidade_itens_pedido)) AS total_do_pedido
           FROM (public.produto_pedido pp_1
             JOIN public.produto p ON ((p.cod_produto = pp_1.cod_produto)))
          WHERE (pp_1.cod_pedido = 3)) AS total_do_pedido
   FROM ((((((((public.envio en
     LEFT JOIN public.pedido ped ON ((ped.cod_pedido = en.cod_pedido)))
     LEFT JOIN public.cliente cli ON ((cli.cod_cliente = ped.cod_cliente)))
     LEFT JOIN public.endereco ende ON ((ende.cod_endereco = cli.cod_endereco)))
     LEFT JOIN public.produto_pedido pp ON ((pp.cod_pedido = ped.cod_pedido)))
     LEFT JOIN public.produto prod ON ((prod.cod_produto = pp.cod_produto)))
     LEFT JOIN public.produto_funcionario pf ON ((pf.cod_produto = prod.cod_produto)))
     LEFT JOIN public.funcionario f ON ((f.cod_funcionario = pf.cod_funcionario)))
     LEFT JOIN public.categoria cat ON ((cat.cod_categoria = prod.cod_categoria)))
  WHERE (en.cod_pedido IN ( SELECT ped_1.cod_pedido
           FROM (public.pedido ped_1
             JOIN public.envio en_1 ON ((en_1.cod_pedido = ped_1.cod_pedido)))
          WHERE (en_1.cod_pedido = 3)))
  GROUP BY cli.nome_completo, cli.cpf, ende.cep, ped.cod_pedido, ped.data_pedido, prod.cod_produto, prod.nome, pp.quantidade_itens_pedido, prod.valor_unitario, en.cod_envio, en.data_envio, cat.nome, f.nome_completo;


ALTER TABLE public.notafiscal_pedido_3 OWNER TO postgres;

--
-- Name: notafiscal_pedido_4; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.notafiscal_pedido_4 AS
 SELECT cli.nome_completo AS cliente,
    cli.cpf,
    ende.cep,
    ped.cod_pedido,
    ped.data_pedido,
    prod.cod_produto,
    prod.nome AS produto,
    pp.quantidade_itens_pedido,
    prod.valor_unitario,
    en.cod_envio,
    en.data_envio,
    cat.nome AS categoria,
    f.nome_completo AS funcionario,
    ( SELECT count(produto_pedido.cod_pedido) AS produtos_no_pedido
           FROM public.produto_pedido
          WHERE (produto_pedido.cod_pedido = 4)) AS produtos_no_pedido,
    ( SELECT sum((p.valor_unitario * pp_1.quantidade_itens_pedido)) AS total_do_pedido
           FROM (public.produto_pedido pp_1
             JOIN public.produto p ON ((p.cod_produto = pp_1.cod_produto)))
          WHERE (pp_1.cod_pedido = 4)) AS total_do_pedido
   FROM ((((((((public.envio en
     LEFT JOIN public.pedido ped ON ((ped.cod_pedido = en.cod_pedido)))
     LEFT JOIN public.cliente cli ON ((cli.cod_cliente = ped.cod_cliente)))
     LEFT JOIN public.endereco ende ON ((ende.cod_endereco = cli.cod_endereco)))
     LEFT JOIN public.produto_pedido pp ON ((pp.cod_pedido = ped.cod_pedido)))
     LEFT JOIN public.produto prod ON ((prod.cod_produto = pp.cod_produto)))
     LEFT JOIN public.produto_funcionario pf ON ((pf.cod_produto = prod.cod_produto)))
     LEFT JOIN public.funcionario f ON ((f.cod_funcionario = pf.cod_funcionario)))
     LEFT JOIN public.categoria cat ON ((cat.cod_categoria = prod.cod_categoria)))
  WHERE (en.cod_pedido IN ( SELECT ped_1.cod_pedido
           FROM (public.pedido ped_1
             JOIN public.envio en_1 ON ((en_1.cod_pedido = ped_1.cod_pedido)))
          WHERE (en_1.cod_pedido = 4)))
  GROUP BY cli.nome_completo, cli.cpf, ende.cep, ped.cod_pedido, ped.data_pedido, prod.cod_produto, prod.nome, pp.quantidade_itens_pedido, prod.valor_unitario, en.cod_envio, en.data_envio, cat.nome, f.nome_completo;


ALTER TABLE public.notafiscal_pedido_4 OWNER TO postgres;

--
-- Name: notafiscal_pedido_5; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.notafiscal_pedido_5 AS
 SELECT cli.nome_completo AS cliente,
    cli.cpf,
    ende.cep,
    ped.cod_pedido,
    ped.data_pedido,
    prod.cod_produto,
    prod.nome AS produto,
    pp.quantidade_itens_pedido,
    prod.valor_unitario,
    en.cod_envio,
    en.data_envio,
    cat.nome AS categoria,
    f.nome_completo AS funcionario,
    ( SELECT count(produto_pedido.cod_pedido) AS produtos_no_pedido
           FROM public.produto_pedido
          WHERE (produto_pedido.cod_pedido = 5)) AS produtos_no_pedido,
    ( SELECT sum((p.valor_unitario * pp_1.quantidade_itens_pedido)) AS total_do_pedido
           FROM (public.produto_pedido pp_1
             JOIN public.produto p ON ((p.cod_produto = pp_1.cod_produto)))
          WHERE (pp_1.cod_pedido = 5)) AS total_do_pedido
   FROM ((((((((public.envio en
     LEFT JOIN public.pedido ped ON ((ped.cod_pedido = en.cod_pedido)))
     LEFT JOIN public.cliente cli ON ((cli.cod_cliente = ped.cod_cliente)))
     LEFT JOIN public.endereco ende ON ((ende.cod_endereco = cli.cod_endereco)))
     LEFT JOIN public.produto_pedido pp ON ((pp.cod_pedido = ped.cod_pedido)))
     LEFT JOIN public.produto prod ON ((prod.cod_produto = pp.cod_produto)))
     LEFT JOIN public.produto_funcionario pf ON ((pf.cod_produto = prod.cod_produto)))
     LEFT JOIN public.funcionario f ON ((f.cod_funcionario = pf.cod_funcionario)))
     LEFT JOIN public.categoria cat ON ((cat.cod_categoria = prod.cod_categoria)))
  WHERE (en.cod_pedido IN ( SELECT ped_1.cod_pedido
           FROM (public.pedido ped_1
             JOIN public.envio en_1 ON ((en_1.cod_pedido = ped_1.cod_pedido)))
          WHERE (en_1.cod_pedido = 5)))
  GROUP BY cli.nome_completo, cli.cpf, ende.cep, ped.cod_pedido, ped.data_pedido, prod.cod_produto, prod.nome, pp.quantidade_itens_pedido, prod.valor_unitario, en.cod_envio, en.data_envio, cat.nome, f.nome_completo;


ALTER TABLE public.notafiscal_pedido_5 OWNER TO postgres;

--
-- Name: notafiscal_pedido_6; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.notafiscal_pedido_6 AS
 SELECT cli.nome_completo AS cliente,
    cli.cpf,
    ende.cep,
    ped.cod_pedido,
    ped.data_pedido,
    prod.cod_produto,
    prod.nome AS produto,
    pp.quantidade_itens_pedido,
    prod.valor_unitario,
    en.cod_envio,
    en.data_envio,
    cat.nome AS categoria,
    f.nome_completo AS funcionario,
    ( SELECT count(produto_pedido.cod_pedido) AS produtos_no_pedido
           FROM public.produto_pedido
          WHERE (produto_pedido.cod_pedido = 6)) AS produtos_no_pedido,
    ( SELECT sum((p.valor_unitario * pp_1.quantidade_itens_pedido)) AS total_do_pedido
           FROM (public.produto_pedido pp_1
             JOIN public.produto p ON ((p.cod_produto = pp_1.cod_produto)))
          WHERE (pp_1.cod_pedido = 6)) AS total_do_pedido
   FROM ((((((((public.envio en
     LEFT JOIN public.pedido ped ON ((ped.cod_pedido = en.cod_pedido)))
     LEFT JOIN public.cliente cli ON ((cli.cod_cliente = ped.cod_cliente)))
     LEFT JOIN public.endereco ende ON ((ende.cod_endereco = cli.cod_endereco)))
     LEFT JOIN public.produto_pedido pp ON ((pp.cod_pedido = ped.cod_pedido)))
     LEFT JOIN public.produto prod ON ((prod.cod_produto = pp.cod_produto)))
     LEFT JOIN public.produto_funcionario pf ON ((pf.cod_produto = prod.cod_produto)))
     LEFT JOIN public.funcionario f ON ((f.cod_funcionario = pf.cod_funcionario)))
     LEFT JOIN public.categoria cat ON ((cat.cod_categoria = prod.cod_categoria)))
  WHERE (en.cod_pedido IN ( SELECT ped_1.cod_pedido
           FROM (public.pedido ped_1
             JOIN public.envio en_1 ON ((en_1.cod_pedido = ped_1.cod_pedido)))
          WHERE (en_1.cod_pedido = 6)))
  GROUP BY cli.nome_completo, cli.cpf, ende.cep, ped.cod_pedido, ped.data_pedido, prod.cod_produto, prod.nome, pp.quantidade_itens_pedido, prod.valor_unitario, en.cod_envio, en.data_envio, cat.nome, f.nome_completo;


ALTER TABLE public.notafiscal_pedido_6 OWNER TO postgres;

--
-- Name: notafiscal_pedido_7; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.notafiscal_pedido_7 AS
 SELECT cli.nome_completo AS cliente,
    cli.cpf,
    ende.cep,
    ped.cod_pedido,
    ped.data_pedido,
    prod.cod_produto,
    prod.nome AS produto,
    pp.quantidade_itens_pedido,
    prod.valor_unitario,
    en.cod_envio,
    en.data_envio,
    cat.nome AS categoria,
    f.nome_completo AS funcionario,
    ( SELECT count(produto_pedido.cod_pedido) AS produtos_no_pedido
           FROM public.produto_pedido
          WHERE (produto_pedido.cod_pedido = 7)) AS produtos_no_pedido,
    ( SELECT sum((p.valor_unitario * pp_1.quantidade_itens_pedido)) AS total_do_pedido
           FROM (public.produto_pedido pp_1
             JOIN public.produto p ON ((p.cod_produto = pp_1.cod_produto)))
          WHERE (pp_1.cod_pedido = 7)) AS total_do_pedido
   FROM ((((((((public.envio en
     LEFT JOIN public.pedido ped ON ((ped.cod_pedido = en.cod_pedido)))
     LEFT JOIN public.cliente cli ON ((cli.cod_cliente = ped.cod_cliente)))
     LEFT JOIN public.endereco ende ON ((ende.cod_endereco = cli.cod_endereco)))
     LEFT JOIN public.produto_pedido pp ON ((pp.cod_pedido = ped.cod_pedido)))
     LEFT JOIN public.produto prod ON ((prod.cod_produto = pp.cod_produto)))
     LEFT JOIN public.produto_funcionario pf ON ((pf.cod_produto = prod.cod_produto)))
     LEFT JOIN public.funcionario f ON ((f.cod_funcionario = pf.cod_funcionario)))
     LEFT JOIN public.categoria cat ON ((cat.cod_categoria = prod.cod_categoria)))
  WHERE (en.cod_pedido IN ( SELECT ped_1.cod_pedido
           FROM (public.pedido ped_1
             JOIN public.envio en_1 ON ((en_1.cod_pedido = ped_1.cod_pedido)))
          WHERE (en_1.cod_pedido = 7)))
  GROUP BY cli.nome_completo, cli.cpf, ende.cep, ped.cod_pedido, ped.data_pedido, prod.cod_produto, prod.nome, pp.quantidade_itens_pedido, prod.valor_unitario, en.cod_envio, en.data_envio, cat.nome, f.nome_completo;


ALTER TABLE public.notafiscal_pedido_7 OWNER TO postgres;

--
-- Name: pedido_cod_pedido_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_cod_pedido_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_cod_pedido_seq OWNER TO postgres;

--
-- Name: pedido_cod_pedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_cod_pedido_seq OWNED BY public.pedido.cod_pedido;


--
-- Name: produto_cod_produto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_cod_produto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_cod_produto_seq OWNER TO postgres;

--
-- Name: produto_cod_produto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_cod_produto_seq OWNED BY public.produto.cod_produto;


--
-- Name: produto_funcionario_cod_produto_funcionario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_funcionario_cod_produto_funcionario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_funcionario_cod_produto_funcionario_seq OWNER TO postgres;

--
-- Name: produto_funcionario_cod_produto_funcionario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_funcionario_cod_produto_funcionario_seq OWNED BY public.produto_funcionario.cod_produto_funcionario;


--
-- Name: produto_pedido_cod_produto_pedido_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_pedido_cod_produto_pedido_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_pedido_cod_produto_pedido_seq OWNER TO postgres;

--
-- Name: produto_pedido_cod_produto_pedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_pedido_cod_produto_pedido_seq OWNED BY public.produto_pedido.cod_produto_pedido;


--
-- Name: produtos_geridos_por_funcionario; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.produtos_geridos_por_funcionario AS
 SELECT count(p.cod_produto) AS produtos_geridos_por_funcionario,
    f.nome_completo AS funcionario
   FROM ((public.produto p
     LEFT JOIN public.produto_funcionario pf ON ((pf.cod_produto = p.cod_produto)))
     LEFT JOIN public.funcionario f ON ((f.cod_funcionario = pf.cod_funcionario)))
  GROUP BY f.nome_completo;


ALTER TABLE public.produtos_geridos_por_funcionario OWNER TO postgres;

--
-- Name: relatorio_de_vendas; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.relatorio_de_vendas AS
 SELECT cli.nome_completo AS cliente,
    cli.cpf,
    ende.cep,
    ped.cod_pedido,
    ped.data_pedido,
    prod.cod_produto,
    prod.nome AS produto,
    pp.quantidade_itens_pedido,
    prod.valor_unitario,
    en.cod_envio,
    en.data_envio,
    cat.nome AS categoria,
    f.nome_completo AS funcionario
   FROM ((((((((public.envio en
     LEFT JOIN public.pedido ped ON ((ped.cod_pedido = en.cod_pedido)))
     LEFT JOIN public.cliente cli ON ((cli.cod_cliente = ped.cod_cliente)))
     LEFT JOIN public.endereco ende ON ((ende.cod_endereco = cli.cod_endereco)))
     LEFT JOIN public.produto_pedido pp ON ((pp.cod_pedido = ped.cod_pedido)))
     LEFT JOIN public.produto prod ON ((prod.cod_produto = pp.cod_produto)))
     LEFT JOIN public.produto_funcionario pf ON ((pf.cod_produto = prod.cod_produto)))
     LEFT JOIN public.funcionario f ON ((f.cod_funcionario = pf.cod_funcionario)))
     LEFT JOIN public.categoria cat ON ((cat.cod_categoria = prod.cod_categoria)))
  GROUP BY cli.nome_completo, cli.cpf, ende.cep, ped.cod_pedido, ped.data_pedido, prod.cod_produto, prod.nome, pp.quantidade_itens_pedido, prod.valor_unitario, en.cod_envio, en.data_envio, cat.nome, f.nome_completo;


ALTER TABLE public.relatorio_de_vendas OWNER TO postgres;

--
-- Name: cod_categoria; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN cod_categoria SET DEFAULT nextval('public.categoria_cod_categoria_seq'::regclass);


--
-- Name: cod_cliente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN cod_cliente SET DEFAULT nextval('public.cliente_cod_cliente_seq'::regclass);


--
-- Name: cod_endereco; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN cod_endereco SET DEFAULT nextval('public.endereco_cod_endereco_seq'::regclass);


--
-- Name: cod_envio; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.envio ALTER COLUMN cod_envio SET DEFAULT nextval('public.envio_cod_envio_seq'::regclass);


--
-- Name: cod_estoque; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque ALTER COLUMN cod_estoque SET DEFAULT nextval('public.estoque_cod_estoque_seq'::regclass);


--
-- Name: cod_funcionario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN cod_funcionario SET DEFAULT nextval('public.funcionario_cod_funcionario_seq'::regclass);


--
-- Name: cod_pedido; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido ALTER COLUMN cod_pedido SET DEFAULT nextval('public.pedido_cod_pedido_seq'::regclass);


--
-- Name: cod_produto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN cod_produto SET DEFAULT nextval('public.produto_cod_produto_seq'::regclass);


--
-- Name: cod_produto_funcionario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_funcionario ALTER COLUMN cod_produto_funcionario SET DEFAULT nextval('public.produto_funcionario_cod_produto_funcionario_seq'::regclass);


--
-- Name: cod_produto_pedido; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_pedido ALTER COLUMN cod_produto_pedido SET DEFAULT nextval('public.produto_pedido_cod_produto_pedido_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2100.dat

--
-- Name: categoria_cod_categoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_cod_categoria_seq', 5, true);


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2094.dat

--
-- Name: cliente_cod_cliente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_cod_cliente_seq', 11, true);


--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2112.dat

--
-- Name: endereco_cod_endereco_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_cod_endereco_seq', 19, true);


--
-- Data for Name: envio; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2110.dat

--
-- Name: envio_cod_envio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.envio_cod_envio_seq', 7, true);


--
-- Data for Name: estoque; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2096.dat

--
-- Name: estoque_cod_estoque_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estoque_cod_estoque_seq', 35, true);


--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2106.dat

--
-- Name: funcionario_cod_funcionario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funcionario_cod_funcionario_seq', 1, false);


--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2098.dat

--
-- Name: pedido_cod_pedido_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_cod_pedido_seq', 7, true);


--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2102.dat

--
-- Name: produto_cod_produto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_cod_produto_seq', 55, true);


--
-- Data for Name: produto_funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2108.dat

--
-- Name: produto_funcionario_cod_produto_funcionario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_funcionario_cod_produto_funcionario_seq', 34, true);


--
-- Data for Name: produto_pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2104.dat

--
-- Name: produto_pedido_cod_produto_pedido_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_pedido_cod_produto_pedido_seq', 23, true);


--
-- Name: categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (cod_categoria);


--
-- Name: cliente_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_cpf_key UNIQUE (cpf);


--
-- Name: cliente_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_email_key UNIQUE (email);


--
-- Name: cliente_nome_usuario_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_nome_usuario_key UNIQUE (nome_usuario);


--
-- Name: cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (cod_cliente);


--
-- Name: endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (cod_endereco);


--
-- Name: envio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.envio
    ADD CONSTRAINT envio_pkey PRIMARY KEY (cod_envio);


--
-- Name: estoque_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.estoque
    ADD CONSTRAINT estoque_pkey PRIMARY KEY (cod_estoque);


--
-- Name: funcionario_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_cpf_key UNIQUE (cpf);


--
-- Name: funcionario_nome_usuario_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_nome_usuario_key UNIQUE (nome_usuario);


--
-- Name: funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (cod_funcionario);


--
-- Name: pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (cod_pedido);


--
-- Name: produto_funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.produto_funcionario
    ADD CONSTRAINT produto_funcionario_pkey PRIMARY KEY (cod_produto_funcionario);


--
-- Name: produto_pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.produto_pedido
    ADD CONSTRAINT produto_pedido_pkey PRIMARY KEY (cod_produto_pedido);


--
-- Name: produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (cod_produto);


--
-- Name: uni; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT uni UNIQUE (cpf);


--
-- Name: cliente_cod_endereco_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_cod_endereco_fkey FOREIGN KEY (cod_endereco) REFERENCES public.endereco(cod_endereco);


--
-- Name: envio_cod_funcionario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.envio
    ADD CONSTRAINT envio_cod_funcionario_fkey FOREIGN KEY (cod_funcionario) REFERENCES public.funcionario(cod_funcionario);


--
-- Name: envio_cod_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.envio
    ADD CONSTRAINT envio_cod_pedido_fkey FOREIGN KEY (cod_pedido) REFERENCES public.pedido(cod_pedido);


--
-- Name: funcionario_cod_endereco_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_cod_endereco_fkey FOREIGN KEY (cod_endereco) REFERENCES public.endereco(cod_endereco);


--
-- Name: pedido_cod_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_cod_cliente_fkey FOREIGN KEY (cod_cliente) REFERENCES public.cliente(cod_cliente);


--
-- Name: produto_cod_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_cod_categoria_fkey FOREIGN KEY (cod_categoria) REFERENCES public.categoria(cod_categoria);


--
-- Name: produto_cod_estoque_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_cod_estoque_fkey FOREIGN KEY (cod_estoque) REFERENCES public.estoque(cod_estoque);


--
-- Name: produto_funcionario_cod_funcionario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_funcionario
    ADD CONSTRAINT produto_funcionario_cod_funcionario_fkey FOREIGN KEY (cod_funcionario) REFERENCES public.funcionario(cod_funcionario);


--
-- Name: produto_funcionario_cod_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_funcionario
    ADD CONSTRAINT produto_funcionario_cod_produto_fkey FOREIGN KEY (cod_produto) REFERENCES public.produto(cod_produto);


--
-- Name: produto_pedido_cod_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_pedido
    ADD CONSTRAINT produto_pedido_cod_pedido_fkey FOREIGN KEY (cod_pedido) REFERENCES public.pedido(cod_pedido);


--
-- Name: produto_pedido_cod_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_pedido
    ADD CONSTRAINT produto_pedido_cod_produto_fkey FOREIGN KEY (cod_produto) REFERENCES public.produto(cod_produto);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

